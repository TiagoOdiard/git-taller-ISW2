# ==========================
# Flyweight (objeto compartido)
# ==========================
class ArbolTipo:
    def __init__(self, nombre, color, textura):
        self.nombre = nombre
        self.color = color
        self.textura = textura

    def mostrar(self, x, y):
        print(f"Árbol '{self.nombre}' en ({x},{y}) - Color: {self.color}, Textura: {self.textura}")


# ==========================
# Flyweight Factory
# ==========================
class ArbolFactory:
    _tipos = {}

    @classmethod
    def obtener_tipo(cls, nombre, color, textura):
        clave = (nombre, color, textura)

        if clave not in cls._tipos:
            print(f"Creando nuevo tipo de árbol: {nombre}")
            cls._tipos[clave] = ArbolTipo(nombre, color, textura)

        return cls._tipos[clave]


# ==========================
# Contexto (objeto con estado externo)
# ==========================
class Arbol:
    def __init__(self, x, y, tipo: ArbolTipo):
        self.x = x
        self.y = y
        self.tipo = tipo

    def mostrar(self):
        self.tipo.mostrar(self.x, self.y)


# ==========================
# Uso
# ==========================
if __name__ == "__main__":

    bosque = []

    # Crear muchos árboles
    bosque.append(Arbol(1, 2, ArbolFactory.obtener_tipo("Pino", "Verde", "Rugosa")))
    bosque.append(Arbol(3, 5, ArbolFactory.obtener_tipo("Pino", "Verde", "Rugosa")))
    bosque.append(Arbol(10, 8, ArbolFactory.obtener_tipo("Roble", "Oscuro", "Lisa")))
    bosque.append(Arbol(7, 6, ArbolFactory.obtener_tipo("Pino", "Verde", "Rugosa")))

    print("\n--- Mostrar bosque ---")
    for arbol in bosque:
        arbol.mostrar()